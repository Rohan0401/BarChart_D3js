import { Component, OnInit, ViewChild, ElementRef, Input,Output, ViewEncapsulation, EventEmitter} from '@angular/core';
import * as d3 from 'd3';
import { BarChartDTO, BarChartDTOoutput } from './bar-chart.dto'
import { constructDependencies } from '@angular/core/src/di/reflective_provider';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css'],
  encapsulation: ViewEncapsulation.None // To include the global CSS 
})
export class BarChartComponent implements OnInit {
  @ViewChild('chart') private chartContainer: ElementRef;  // To provide the first element with the ID 
  @Input() private chartAttributes: BarChartDTO;
  @Output() private outputAttribute : EventEmitter<number> = new EventEmitter<number>();
  private data: any;
  private margin: any; // Provide properties for the chart 
  private chart: any;
  private width: number;
  private height: number;
  private xScale: any;
  private yScale: any;
  private colors: any;
  private xAxis: any;
  private yAxis: any;
 

  constructor() { }

  ngOnInit() { 
    
    
    if (this.chartAttributes.data) {

      this.createChart();
      
      
    }
    this.updateChart(); 
    
    
    
  }



  createChart() {
    const element = this.chartContainer.nativeElement;
    
    // Set the Width and Height 
    this.width = element.offsetWidth - this.chartAttributes.margin.left - this.chartAttributes.margin.right;
    this.height = element.offsetHeight - this.chartAttributes.margin.top - this.chartAttributes.margin.bottom;
    
    const svg = d3.select(element).append('svg')
      .attr('width', element.offsetWidth)
      .attr('height', element.offsetHeight);

    // chart plot area
    this.chart = svg.append('g')
      .attr('class', 'bars')
      .attr('transform', `translate(${this.chartAttributes.margin.left}, ${this.chartAttributes.margin.top})`);
      
    



    // define X & Y domains
    const xDomain = this.chartAttributes.data.map(d => d[0]);
    const yDomain = [0, d3.max(this.chartAttributes.data, d => d[1])];

    // create scales
    this.xScale = d3.scaleBand().padding(0.1).domain(xDomain).rangeRound([0, this.width]);
    this.yScale = d3.scaleLinear().domain(yDomain).range([this.height, 0]);

    // bar colors
    this.colors = d3.scaleLinear().domain([0, this.chartAttributes.data.length]).range(<any[]>['red', 'blue']);

    // x & y axis
    this.xAxis = svg.append('g')
      .attr('class', 'axis axis-x')
      .attr('transform', `translate(${this.chartAttributes.margin.left}, ${this.chartAttributes.margin.top + this.height})`)
      .call(d3.axisBottom(this.xScale));
    this.yAxis = svg.append('g')
      .attr('class', 'axis axis-y')
      .attr('transform', `translate(${this.chartAttributes.margin.left}, ${this.chartAttributes.margin.top})`)
      .call(d3.axisLeft(this.yScale));
    
  

    
  }

  updateChart() {
    // update scales & axis
    this.xScale.domain(this.chartAttributes.data.map(d => d[0]));
    this.yScale.domain([0, d3.max(this.chartAttributes.data, d => d[1])]);
    this.colors.domain([0, this.chartAttributes.data.length]);
    this.xAxis.transition().call(d3.axisBottom(this.xScale));
    this.yAxis.transition().call(d3.axisLeft(this.yScale));
  
    // this binds the data 
    const update = this.chart.selectAll('.bar')
      .data(this.chartAttributes.data);

    // remove exiting bars
    update.exit().remove();


  

    // add new bars
    update
      .enter()
      .append('rect')
      .attr('class', 'bar')
      .attr('x', d => this.xScale(d[0]))
      .attr('y', d => this.yScale(0))
      .attr('width', this.xScale.bandwidth())
      .attr('height', 0)
      .style('fill', (d, i) => this.colors(i))
      .attr('y', d => this.yScale(d[1]))
      .attr('height', d => this.height - this.yScale(d[1]))
      .on("click" , (d => this.outputAttribute.emit(this.height - this.yScale(d[1]))));
      
  }
}